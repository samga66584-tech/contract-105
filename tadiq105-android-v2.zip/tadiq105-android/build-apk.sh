#!/usr/bin/env bash
# بناء APK محليًا. المتطلبات: Node 18+ و Java 17 و Android SDK (متغير ANDROID_HOME)
set -e
npm install
node scripts/copy-fonts.js
[ -d android ] || npx cap add android
node scripts/patch-manifest.js
npx @capacitor/assets generate --android || true
npx cap sync android
cd android && chmod +x gradlew && ./gradlew assembleDebug
echo "الملف جاهز: android/app/build/outputs/apk/debug/app-debug.apk"
