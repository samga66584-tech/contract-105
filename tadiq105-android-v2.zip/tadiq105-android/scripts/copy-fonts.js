// ينسخ خط Cairo (عربي + لاتيني) داخل التطبيق ليعمل بدون إنترنت
const fs = require('fs'), path = require('path');
const dir = 'node_modules/@fontsource-variable/cairo/files';
const out = 'www/fonts';
try {
  fs.mkdirSync(out, { recursive: true });
  const files = fs.readdirSync(dir);
  const pick = (re) => files.find((f) => re.test(f) && /wght-normal\.woff2$/.test(f));
  const ar = pick(/arabic-wght/), la = pick(/(^|-)latin-wght/);
  if (ar) fs.copyFileSync(path.join(dir, ar), path.join(out, 'cairo-arabic.woff2'));
  if (la) fs.copyFileSync(path.join(dir, la), path.join(out, 'cairo-latin.woff2'));
  console.log('fonts copied:', ar, la);
} catch (e) { console.log('fonts skipped (system Arabic font will be used):', e.message); }
