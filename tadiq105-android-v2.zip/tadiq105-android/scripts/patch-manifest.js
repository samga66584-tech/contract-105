// يُنفَّذ بعد "npx cap add android":
// 1) صلاحيات الموقع  2) لون خلفية داكن هادئ بدل الشاشة البيضاء  3) إعدادات مناسبة للتطبيق
const fs = require('fs');
const path = require('path');
const res = 'android/app/src/main/res';

// ---- 1) AndroidManifest ----
const mf = 'android/app/src/main/AndroidManifest.xml';
let x = fs.readFileSync(mf, 'utf8');
let add = '';
for (const p of ['android.permission.ACCESS_FINE_LOCATION', 'android.permission.ACCESS_COARSE_LOCATION', 'android.permission.ACCESS_NETWORK_STATE'])
  if (!x.includes(p)) add += `\n    <uses-permission android:name="${p}" />`;
if (add) x = x.replace('</manifest>', add.trimStart() + '\n</manifest>');
// استعلامات (Android 11+) لفتح واتساب والاتصال والبريد
if (!x.includes('<queries>')) {
  x = x.replace('</manifest>', `    <queries>
        <intent><action android:name="android.intent.action.VIEW" /><data android:scheme="https" /></intent>
        <intent><action android:name="android.intent.action.VIEW" /><data android:scheme="whatsapp" /></intent>
        <intent><action android:name="android.intent.action.DIAL" /></intent>
        <intent><action android:name="android.intent.action.SENDTO" /><data android:scheme="mailto" /></intent>
        <package android:name="com.whatsapp" />
        <package android:name="com.whatsapp.w4b" />
    </queries>
</manifest>`);
}
fs.writeFileSync(mf, x);

// ---- 2) ألوان + ثيم (لا شاشة بيضاء) ----
const colors = path.join(res, 'values/colors.xml');
let c = fs.existsSync(colors) ? fs.readFileSync(colors, 'utf8') : '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n</resources>\n';
if (!c.includes('tadiq_bg')) c = c.replace('</resources>', '    <color name="tadiq_bg">#0F1C24</color>\n</resources>');
fs.writeFileSync(colors, c);

const st = path.join(res, 'values/styles.xml');
if (fs.existsSync(st)) {
  let s = fs.readFileSync(st, 'utf8');
  s = s.replace(/@drawable\/splash/g, '@color/tadiq_bg');
  // خلفية النافذة داكنة في كل الثيمات
  s = s.replace(/(<style name="AppTheme\.NoActionBar"[^>]*>)/, '$1\n        <item name="android:windowBackground">@color/tadiq_bg</item>\n        <item name="android:statusBarColor">@color/tadiq_bg</item>\n        <item name="android:navigationBarColor">@color/tadiq_bg</item>');
  s = s.replace(/(<style name="AppTheme"[^>]*>)/, '$1\n        <item name="android:windowBackground">@color/tadiq_bg</item>');
  if (/AppTheme\.NoActionBarLaunch/.test(s) && !s.includes('windowSplashScreenBackground'))
    s = s.replace(/(<style name="AppTheme\.NoActionBarLaunch"[^>]*>)/, '$1\n        <item name="windowSplashScreenBackground">@color/tadiq_bg</item>');
  fs.writeFileSync(st, s);
}
console.log('patch ok: permissions + queries + dark theme');
